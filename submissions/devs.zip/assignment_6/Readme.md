# DEVS Assignment
## Getting started
```shell
cd pythonpdevs/src
python setup.py install --user
python -c "import pypdevs"
```
