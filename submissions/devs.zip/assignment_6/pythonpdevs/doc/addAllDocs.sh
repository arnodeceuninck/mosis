#!/bin/bash
svn add *.rst
svn add _build/html/*.html
svn add _build/html/sources/*.txt
svn add _build/html/modules/*.html
